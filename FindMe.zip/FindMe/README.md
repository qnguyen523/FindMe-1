# FindMe
FindMe is a location sharing and messaging Android application. It allows users to share their location in real­time and communicate with their peers for group activities.

# Team Members
Troy Nguyen, Bhargava Ramisetty, Hezekiah Valdez, Quoc Nguyen
